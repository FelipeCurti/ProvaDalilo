﻿namespace Forca
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.opnFlDlgDados = new System.Windows.Forms.OpenFileDialog();
            this.btnStart = new System.Windows.Forms.Button();
            this.txtbxLetras = new System.Windows.Forms.TextBox();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn14 = new System.Windows.Forms.Button();
            this.btn13 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.rchTxtBxLetras = new System.Windows.Forms.RichTextBox();
            this.lblDica1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblDica2 = new System.Windows.Forms.Label();
            this.lblnumpa = new System.Windows.Forms.Label();
            this.pctrBxImagens = new System.Windows.Forms.PictureBox();
            this.btnValidar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pctrBxImagens)).BeginInit();
            this.SuspendLayout();
            // 
            // opnFlDlgDados
            // 
            this.opnFlDlgDados.FileName = "Nomes Forca.txt";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(691, 12);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // txtbxLetras
            // 
            this.txtbxLetras.Location = new System.Drawing.Point(567, 13);
            this.txtbxLetras.MaxLength = 1;
            this.txtbxLetras.Name = "txtbxLetras";
            this.txtbxLetras.Size = new System.Drawing.Size(45, 20);
            this.txtbxLetras.TabIndex = 2;
            this.txtbxLetras.Visible = false;
            // 
            // btn0
            // 
            this.btn0.Enabled = false;
            this.btn0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0.Location = new System.Drawing.Point(211, 245);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(37, 34);
            this.btn0.TabIndex = 4;
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Visible = false;
            // 
            // btn1
            // 
            this.btn1.Enabled = false;
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(248, 245);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(37, 34);
            this.btn1.TabIndex = 20;
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Visible = false;
            // 
            // btn2
            // 
            this.btn2.Enabled = false;
            this.btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.Location = new System.Drawing.Point(285, 245);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(37, 34);
            this.btn2.TabIndex = 21;
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Visible = false;
            // 
            // btn3
            // 
            this.btn3.Enabled = false;
            this.btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.Location = new System.Drawing.Point(322, 245);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(37, 34);
            this.btn3.TabIndex = 22;
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Visible = false;
            // 
            // btn4
            // 
            this.btn4.Enabled = false;
            this.btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.Location = new System.Drawing.Point(359, 245);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(37, 34);
            this.btn4.TabIndex = 23;
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Visible = false;
            // 
            // btn9
            // 
            this.btn9.Enabled = false;
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(544, 245);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(37, 34);
            this.btn9.TabIndex = 28;
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Visible = false;
            // 
            // btn8
            // 
            this.btn8.Enabled = false;
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.Location = new System.Drawing.Point(507, 245);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(37, 34);
            this.btn8.TabIndex = 27;
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Visible = false;
            // 
            // btn7
            // 
            this.btn7.Enabled = false;
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.Location = new System.Drawing.Point(470, 245);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(37, 34);
            this.btn7.TabIndex = 26;
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Visible = false;
            // 
            // btn6
            // 
            this.btn6.Enabled = false;
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(433, 245);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(37, 34);
            this.btn6.TabIndex = 25;
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Visible = false;
            // 
            // btn5
            // 
            this.btn5.Enabled = false;
            this.btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.Location = new System.Drawing.Point(396, 245);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(37, 34);
            this.btn5.TabIndex = 24;
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Visible = false;
            // 
            // btn14
            // 
            this.btn14.Enabled = false;
            this.btn14.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn14.Location = new System.Drawing.Point(729, 245);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(37, 34);
            this.btn14.TabIndex = 33;
            this.btn14.UseVisualStyleBackColor = true;
            this.btn14.Visible = false;
            // 
            // btn13
            // 
            this.btn13.Enabled = false;
            this.btn13.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn13.Location = new System.Drawing.Point(692, 245);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(37, 34);
            this.btn13.TabIndex = 32;
            this.btn13.UseVisualStyleBackColor = true;
            this.btn13.Visible = false;
            // 
            // btn12
            // 
            this.btn12.Enabled = false;
            this.btn12.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn12.Location = new System.Drawing.Point(655, 245);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(37, 34);
            this.btn12.TabIndex = 31;
            this.btn12.UseVisualStyleBackColor = true;
            this.btn12.Visible = false;
            // 
            // btn11
            // 
            this.btn11.Enabled = false;
            this.btn11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn11.Location = new System.Drawing.Point(618, 245);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(37, 34);
            this.btn11.TabIndex = 30;
            this.btn11.UseVisualStyleBackColor = true;
            this.btn11.Visible = false;
            // 
            // btn10
            // 
            this.btn10.Enabled = false;
            this.btn10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn10.Location = new System.Drawing.Point(581, 245);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(37, 34);
            this.btn10.TabIndex = 29;
            this.btn10.UseVisualStyleBackColor = true;
            this.btn10.Visible = false;
            // 
            // rchTxtBxLetras
            // 
            this.rchTxtBxLetras.Enabled = false;
            this.rchTxtBxLetras.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBxLetras.Location = new System.Drawing.Point(13, 286);
            this.rchTxtBxLetras.Name = "rchTxtBxLetras";
            this.rchTxtBxLetras.Size = new System.Drawing.Size(753, 112);
            this.rchTxtBxLetras.TabIndex = 34;
            this.rchTxtBxLetras.Text = " ";
            // 
            // lblDica1
            // 
            this.lblDica1.AutoSize = true;
            this.lblDica1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDica1.ForeColor = System.Drawing.Color.Red;
            this.lblDica1.Location = new System.Drawing.Point(314, 69);
            this.lblDica1.Name = "lblDica1";
            this.lblDica1.Size = new System.Drawing.Size(0, 25);
            this.lblDica1.TabIndex = 36;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(213, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 31);
            this.label1.TabIndex = 37;
            this.label1.Text = "Dica 1: ";
            this.label1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(213, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 31);
            this.label2.TabIndex = 39;
            this.label2.Text = "Dica 2: ";
            this.label2.Visible = false;
            // 
            // lblDica2
            // 
            this.lblDica2.AutoSize = true;
            this.lblDica2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDica2.ForeColor = System.Drawing.Color.Red;
            this.lblDica2.Location = new System.Drawing.Point(314, 117);
            this.lblDica2.Name = "lblDica2";
            this.lblDica2.Size = new System.Drawing.Size(0, 25);
            this.lblDica2.TabIndex = 38;
            // 
            // lblnumpa
            // 
            this.lblnumpa.AutoSize = true;
            this.lblnumpa.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnumpa.Location = new System.Drawing.Point(2, 399);
            this.lblnumpa.Name = "lblnumpa";
            this.lblnumpa.Size = new System.Drawing.Size(8, 7);
            this.lblnumpa.TabIndex = 40;
            this.lblnumpa.Text = "0";
            // 
            // pctrBxImagens
            // 
            this.pctrBxImagens.Image = global::Forca.Properties.Resources.foto1;
            this.pctrBxImagens.Location = new System.Drawing.Point(12, 12);
            this.pctrBxImagens.Name = "pctrBxImagens";
            this.pctrBxImagens.Size = new System.Drawing.Size(193, 267);
            this.pctrBxImagens.TabIndex = 35;
            this.pctrBxImagens.TabStop = false;
            // 
            // btnValidar
            // 
            this.btnValidar.Image = global::Forca.Properties.Resources.botao;
            this.btnValidar.Location = new System.Drawing.Point(618, 12);
            this.btnValidar.Name = "btnValidar";
            this.btnValidar.Size = new System.Drawing.Size(32, 23);
            this.btnValidar.TabIndex = 3;
            this.btnValidar.Text = "||>";
            this.btnValidar.UseVisualStyleBackColor = true;
            this.btnValidar.Visible = false;
            this.btnValidar.Click += new System.EventHandler(this.btnValidar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 408);
            this.Controls.Add(this.lblnumpa);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblDica2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblDica1);
            this.Controls.Add(this.pctrBxImagens);
            this.Controls.Add(this.rchTxtBxLetras);
            this.Controls.Add(this.btn14);
            this.Controls.Add(this.btn13);
            this.Controls.Add(this.btn12);
            this.Controls.Add(this.btn11);
            this.Controls.Add(this.btn10);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btnValidar);
            this.Controls.Add(this.txtbxLetras);
            this.Controls.Add(this.btnStart);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Forca";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pctrBxImagens)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog opnFlDlgDados;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.TextBox txtbxLetras;
        private System.Windows.Forms.Button btnValidar;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn14;
        private System.Windows.Forms.Button btn13;
        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.RichTextBox rchTxtBxLetras;
        private System.Windows.Forms.PictureBox pctrBxImagens;
        private System.Windows.Forms.Label lblDica1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblDica2;
        private System.Windows.Forms.Label lblnumpa;
    }
}

