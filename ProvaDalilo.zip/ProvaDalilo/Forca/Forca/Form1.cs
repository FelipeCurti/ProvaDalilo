﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Forca
{
    public partial class Form1 : Form
    {
        Variaveis.Class1 VariaveisScript = new Variaveis.Class1();

        public Form1()
        {
            InitializeComponent();
            VariaveisScript.tamanho = 0;
            VariaveisScript.erro = 1;
            VariaveisScript.valor = 0;
            VariaveisScript.valor2 = 1;
            VariaveisScript.zero = 1;
            VariaveisScript.zero2 = 1;
            VariaveisScript.inicioe = 0;
            VariaveisScript.numeroradmuda = -1;
            VariaveisScript.palavraesco = null;
            VariaveisScript.dica = null;
            VariaveisScript.dica2 = null;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Abre pasta para procurar o arquivo txt
            opnFlDlgDados.ShowDialog();
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            char[] letrasb = palavras().ToCharArray();
                           
                for (int conti = 0; conti < letrasb.Length; conti++)
                {
                    string botao = "btn" + conti.ToString();
                    if (letrasb[conti].ToString().ToUpper() == txtbxLetras.Text.ToUpper())
                    {
                        this.Controls.Find(botao, false)[0].Text = letrasb[conti].ToString();
                        valortmp();
                        zerando();
                    if(VariaveisScript.zero == 0)
                    {
                        MessageBox.Show("voce ganhou");
                        pctrBxImagens.Image = Properties.Resources.foto1;
                        restart();
                        inicio();
                        VariaveisScript.inicioe = 1;
                        break;
                    }
                }

                }
                for (int conti = 0; conti < letrasb.Length; conti++)
                {
                    if (VariaveisScript.valor == 0 && VariaveisScript.inicioe != 1)
                    {

                        if (VariaveisScript.erro < 6)
                        {
                            rchTxtBxLetras.Text = rchTxtBxLetras.Text.ToUpper() + " " + txtbxLetras.Text.ToUpper() + " -";

                            if (VariaveisScript.erro == 1)
                            {
                                pctrBxImagens.Image = Properties.Resources.foto2;
                                adderro();
                            }
                            else if (VariaveisScript.erro == 2)
                            {
                                pctrBxImagens.Image = Properties.Resources.foto3;
                                adderro();
                            }
                            else if (VariaveisScript.erro == 3)
                            {
                                label1.Visible = true;
                                dicaum();
                                pctrBxImagens.Image = Properties.Resources.foto4;
                                adderro();
                            }
                            else if (VariaveisScript.erro == 4)
                            {
                                pctrBxImagens.Image = Properties.Resources.foto5;
                                adderro();
                            }
                            else
                            {
                                pctrBxImagens.Image = Properties.Resources.foto6;
                                adderro();
                            }
                            break;
                        }
                        if (VariaveisScript.erro == 6)
                        {
                            label2.Visible = true;
                            dicadois();
                            rchTxtBxLetras.Text = rchTxtBxLetras.Text.ToUpper() + " " + txtbxLetras.Text.ToUpper();
                            pctrBxImagens.Image = Properties.Resources.foto7;
                            adderro();
                            break;
                        }
                        else
                        {
                            pctrBxImagens.Image = Properties.Resources.foto8;
                            perdeu();
                        restart();
                        inicio();
                        break;
                        }

                    }

                }
            VariaveisScript.valor = 0;
            VariaveisScript.inicioe = 0;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            inicio();
            btnValidar.Visible = true;
            txtbxLetras.Visible = true;
            btnStart.Visible = false;


        }
        void inicio()
        {            
            string[] arquivo = File.ReadAllLines(opnFlDlgDados.FileName);
            VariaveisScript.palavraesco = arquivo[numerorand() - 1];

            char[] letrasb = palavras().ToCharArray();

            for (int cont = 0; cont < letrasb.Length; cont++)
            {
                addtamanho();
                var botao = "btn" + cont.ToString();
                this.Controls.Find(botao, false)[0].Visible = true;
                this.Controls.Find(botao, false)[0].Text = "#";
            }
            for (int teste = addtamanho(); teste < 15; teste++)
            {
                var botao = "btn" + teste.ToString();
                this.Controls.Find(botao, false)[0].Visible = false;
            }
        }    
        int numerorand()
        {
            if(VariaveisScript.numeroradmuda == -1)
            {
                Random randNum = new Random();
                VariaveisScript.numeroradmuda = randNum.Next(1,60);
            }
            lblnumpa.Text = VariaveisScript.numeroradmuda.ToString();
            return VariaveisScript.numeroradmuda;
        }
        int addtamanho()
        {
            return VariaveisScript.tamanho++;
        }
        int adderro()
        {
            return VariaveisScript.erro++;
        }
        string palavras()
        {      
            return VariaveisScript.palavraesco.ToUpper();
        }
        void perdeu()
        {
            if(VariaveisScript.erro == 7)
            {
                MessageBox.Show("Voce perdeu e a palavra era: " + VariaveisScript.palavraesco.ToString().ToUpper());
                
            }
        }  
        int valortmp()
        {            
            return VariaveisScript.valor = VariaveisScript.valor2;
        }
        int zerando()
        {
            VariaveisScript.zero2++;
            return VariaveisScript.zero = VariaveisScript.tamanho - VariaveisScript.zero2;

        }
        void restart()
        {
            pctrBxImagens.Image = Properties.Resources.foto1;
            rchTxtBxLetras.Text = "";
            VariaveisScript.tamanho = 0;
            VariaveisScript.erro = 1;
            VariaveisScript.valor = 0;
            VariaveisScript.valor2 = 1;
            VariaveisScript.zero = 1;
            VariaveisScript.zero2 = 1;
            label1.Visible = false;
            label2.Visible = false;
            lblDica1.Visible = false;
            lblDica2.Visible = false;
            VariaveisScript.numeroradmuda = -1;
        }
        string dicaum()
        {            
            lblDica1.Visible = true;
            if(numerorand() - 1 >= 0 && numerorand() - 1 <= 9)
            {
                VariaveisScript.dica = lblDica1.Text = "CARRO";
            }
            else if (numerorand() - 1 >= 10 && numerorand() - 1 <= 19)
            {
                VariaveisScript.dica = lblDica1.Text = "COMIDA";
            }
            else if (numerorand() - 1 >= 20 && numerorand() - 1 <= 29)
            {
                VariaveisScript.dica = lblDica1.Text = "PAIS";
            }
            else if (numerorand() - 1 >= 30 && numerorand() - 1 <= 39)
            {
                VariaveisScript.dica = lblDica1.Text = "ELETRONICO";
            }
            else if (numerorand() - 1 >= 40 && numerorand() - 1 <= 49)
            {
                VariaveisScript.dica = lblDica1.Text = "MOVEIS";
            }
            else if (numerorand() - 1 >= 50 && numerorand() - 1 <= 59)
            {
                VariaveisScript.dica = lblDica1.Text = "PROFISSÃO";
            }
            return VariaveisScript.dica;
        }
        string dicadois()
        {
            lblDica2.Visible = true;
            if (numerorand() - 1 >= 0 && numerorand() - 1 <= 4)
            {
                VariaveisScript.dica = lblDica2.Text = "FIAT";
            }
            else if (numerorand()-1 >= 5 && numerorand()-1 <= 9)
            {
                VariaveisScript.dica = lblDica2.Text = "TOYOTA";
            }
            else if (numerorand() - 1 >= 10 && numerorand() - 1 <= 14)
            {
                VariaveisScript.dica = lblDica2.Text = "SOBREMESA";
            }
            else if (numerorand() - 1 >= 15 && numerorand() - 1 <= 19)
            {
                VariaveisScript.dica = lblDica2.Text = "CHURRASCO";
            }
            else if (numerorand() - 1 >= 20 && numerorand() - 1 <= 24)
            {
                VariaveisScript.dica = lblDica2.Text = "EUROPA";
            }
            else if (numerorand() - 1 >= 25 && numerorand() - 1 <= 29)
            {
                VariaveisScript.dica = lblDica2.Text = "AMERICA DO SUL";
            }
            else if (numerorand() - 1 >= 30 && numerorand() - 1 <= 34)
            {
                VariaveisScript.dica = lblDica2.Text = "PERIFERICO";
            }
            else if (numerorand() - 1 >= 35 && numerorand() - 1 <= 39)
            {
                VariaveisScript.dica = lblDica2.Text = "MARCA";
            }
            else if (numerorand() - 1 >= 40 && numerorand() - 1 <= 44)
            {
                VariaveisScript.dica = lblDica2.Text = "COZINHA";
            }
            else if (numerorand() - 1 >= 45 && numerorand() - 1 <= 49)
            {
                VariaveisScript.dica = lblDica2.Text = "QUARTO";
            }
            else if (numerorand() - 1 >= 50 && numerorand() - 1 <= 54)
            {
                VariaveisScript.dica = lblDica2.Text = "SAÚDE";
            }
            else if (numerorand() - 1 >= 55 && numerorand() - 1 <= 59)
            {
                VariaveisScript.dica = lblDica2.Text = "EXATAS";
            }
            return VariaveisScript.dica2;
        }
    }
}
