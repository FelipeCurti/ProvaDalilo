﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Forca.Variaveis
{
    class Class1
    {
        public int tamanho { get; set; }
        public int erro { get; set; }
        public int valor { get; set; }
        public int valor2 { get; set; }
        public int zero { get; set; }
        public int zero2 { get; set; }
        public int inicioe { get; set; }
        public int numeroradmuda { get; set; }
        public string palavraesco { get; set; }
        public string dica { get; set; }
        public string dica2 { get; set; }
    }
}
